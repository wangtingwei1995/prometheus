./redis_exporter  -redis.addr 172.24.14.24:6379 -redis.password y5Wa8crt#9#P1ffT &
curl localhost:9121/metrics
